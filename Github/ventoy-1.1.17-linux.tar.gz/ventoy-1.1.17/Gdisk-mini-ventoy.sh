#!/bin/bash

sudo rm -f /tmp/Gdisk-2.0-Ventoy.img
head -c 33999k /dev/urandom > /tmp/Gdisk-2.0-Ventoy.img
sudo losetup -P /dev/loop999 /tmp/Gdisk-2.0-Ventoy.img
sudo bash Ventoy2Disk.sh -I /dev/loop999
sudo mkdir -p /mnt/loop999p1 && sudo mount /dev/loop999p1 /mnt/loop999p1
sudo touch /mnt/loop999p1/.ventoyignore
sudo umount -l /dev/loop999p1
sudo losetup -d /dev/loop999

echo
echo "Minimal Gdisk Ventoy image created at /tmp/Gdisk-2.0-Ventoy.img"
echo
read -p ' '