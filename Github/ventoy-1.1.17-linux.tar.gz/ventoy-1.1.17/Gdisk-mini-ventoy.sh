#!/bin/bash

cd /tmp/ventoy-1.1.17/
sudo rm -f /tmp/Gdisk-3.2-Ventoy.img
head -c 33999k /dev/urandom > /tmp/Gdisk-3.2-Ventoy.img
sudo losetup -P /dev/loop999 /tmp/Gdisk-3.2-Ventoy.img
printf 'y\ny\n' | sudo bash Ventoy2Disk.sh -I /dev/loop999 -L 'Gdisk-Ventoy'
sudo mkdir -p /mnt/loop999p1 && sudo mount /dev/loop999p1 /mnt/loop999p1
sudo touch /mnt/loop999p1/.ventoyignore
sudo umount -l /dev/loop999p1
sudo losetup -d /dev/loop999

echo
echo "Minimal Gdisk Ventoy image created"
echo
sleep 1